public class TransportFactory {
    public static TransportStrategy getTransportStrategy(PackageInfo pkg, DestinationInfo destination) {
        if (destination.isInternational()) {
            return new SeaTransport();
        } else if (destination.isMetropolitan() && pkg.getWeight() <= 2) {
            return new DroneTransport();
        } else if (pkg.getWeight() <= 20 && !pkg.getDimensions().exceeds(50, 50, 50)) {
            return new AirTransport();
        } else {
            return new GroundTransport();
        }
    }
}
