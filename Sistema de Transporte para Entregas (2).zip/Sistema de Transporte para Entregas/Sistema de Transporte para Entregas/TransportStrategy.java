public interface TransportStrategy {
    String deliver(PackageInfo pkg, DestinationInfo destination);
}
