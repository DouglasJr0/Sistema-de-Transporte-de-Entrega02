public class DroneTransport implements TransportStrategy {
    @Override
    public String deliver(PackageInfo pkg, DestinationInfo destination) {
        if (!destination.isMetropolitan() || pkg.getWeight() > 2) {
            return "Entrega por drones é limitada a áreas metropolitanas e pequenos pacotes.";
        }
        return "Entregando por drone para " + destination.getLocation() + ".";
    }
}
