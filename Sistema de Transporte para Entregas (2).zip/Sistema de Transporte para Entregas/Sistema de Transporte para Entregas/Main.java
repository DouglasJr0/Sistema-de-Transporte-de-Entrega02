public class Main {
    public static void main(String[] args) {
        // Exemplo de pacote e destino
        PackageInfo pkg = new PackageInfo(10, new Dimensions(40, 30, 20));
        DestinationInfo destination = new DestinationInfo("São Paulo", false, true);

        // Usando o TransportSelector
        TransportSelector selector = new TransportSelector();
        String result = selector.selectAndDeliver(pkg, destination);

        // Exibir resultado
        System.out.println(result);
    }
}
