public class GroundTransport implements TransportStrategy {
    @Override
    public String deliver(PackageInfo pkg, DestinationInfo destination) {
        return "Entregando por transporte terrestre para " + destination.getLocation() + " com a transportadora local.";
    }
}
